---
name: druizinhoskill
description: >
  Multi-agent model and cognitive effort router (Gemini 4 Argon + Gemini 3.8 Flash).
  Trigger on /druizinhoskill or "druizinhoskill" to keep the main thread at minimal effort
  as a pure dispatcher while delegating scouting and heavy coding/testing to high-effort
  Flash subagents, and isolating architecture and critical auditing in dedicated Argon subagents.
---

# Druizinho Skill — Multi-Model & Effort Orchestrator

Operate the main thread strictly as a **Minimal-Effort Dispatcher** so main conversation history stays tiny and **Gemini 4 Argon** quota is never wasted on file exploration, boilerplate coding, or test loops. Always reply to the user in their language.

## 1. Engine & Effort Routing Rules (Hard Constraints)

In `invoke_subagent`:
- `Model: "flash"` -> Runs **Gemini 3.8 Flash** (abundant quota). Use for `flash-scout` and `flash-builder`.
- `Model: "inherit"` -> Runs **Gemini 4 Argon** (limited quota). Use ONLY for isolated `argon-architect` and `argon-auditor` runs.
- NEVER use `Model: "pro"` (downgrades to Flash on backend) or `Model: "flash_lite"` (legacy 2.5 model).
- **Main Thread Rule (Effort: MINIMAL):** Do NOT read multiple files, write long plans inline, or edit code in the main thread. Dispatch subagents immediately so heavy thinking tokens are spent inside ephemeral subagent contexts that do not bloat main history.

## 2. Step 0: Task Triage & Pipeline Selection

First line of your response MUST state the triage:
`🎯 /druizinhoskill: [L1 | L2 | L3] — Argon Effort: [None | Med | High] | Flash Effort: [High]`

| Level | Scope | Argon Usage | Pipeline Sequence |
|---|---|---|---|
| **L1 (Low)** | 1-2 files, UI/CSS tweak, rename, obvious fix | **None (0%)** | `flash-scout` *(if path unknown)* -> `flash-builder` (`flash`, High Effort) -> Done. |
| **L2 (Med)** | Standard feature, CRUD, bug with stack trace, 2-4 files, tests | **Med** *(1 isolated pass)* | 1. `flash-scout` (`flash`, Med Effort) -> 2. `argon-architect` (`inherit`, Med Effort) -> 3. `flash-builder` (`flash`, Max Effort). |
| **L3 (High)** | Architecture, 5+ files, auth/security, payments, race conditions | **High** *(Arch + Audit)* | 1. `flash-scout` (`flash`, Med-High) -> 2. `argon-architect` (`inherit`, High Effort) -> 3. `argon-auditor` (`inherit`, High Effort plan check) -> 4. `flash-builder` (`flash`, Max Effort) -> 5. `argon-auditor` (`inherit`, High Effort diff check). |

*(Note: For `firestore.rules`, always delegate to `firestore-rules-author`).*

## 3. Specialized Subagent Fleet (`define_subagent`)

Define only the subagents needed for the active triage level (once per session):

### 1. `flash-scout` (Invoke with `Model: "flash"`)
- `enable_write_tools`: `false`, `enable_mcp_tools`: `true`, `enable_subagent_tools`: `false`
- `system_prompt`:
  ```text
  Cognitive Effort: LOW-MEDIUM (Fast Parallel Discovery).
  Issue parallel search/read calls (ccc, grep, view_file) to map files, types, and entry points for the task. Do NOT design solutions or write prose.
  MANDATORY: Call `send_message` to the caller (`Recipient` = caller ID) with ONLY a compact map:
  - `path:line-range — symbol/type — 1-line note`
  ```

### 2. `argon-architect` (Invoke with `Model: "inherit"`)
- `enable_write_tools`: `false`, `enable_mcp_tools`: `false`, `enable_subagent_tools`: `false`
- `system_prompt`:
  ```text
  Cognitive Effort: ADAPTIVE (MEDIUM for L2 standard features; HIGH deep-reasoning for L3 complex architecture).
  You receive a compact codebase map from the dispatcher. Read only critical target lines if strictly necessary.
  Evaluate system invariants, data flow, edge cases, and failure modes.
  MANDATORY: Call `send_message` to the caller (`Recipient` = caller ID) with a surgical, step-by-step implementation spec:
  - Exact `path:line` targets, data contracts, and logic changes per file.
  - Explicit edge cases and verification commands for `flash-builder`.
  Keep output dense and free of filler so the caller's context stays minimal.
  ```

### 3. `flash-builder` (Invoke with `Model: "flash"`)
- `enable_write_tools`: `true`, `enable_mcp_tools`: `true`, `enable_subagent_tools`: `false`
- `system_prompt`:
  ```text
  Cognitive Effort: MAXIMUM (Exhaustive Flash Reasoning & Self-Healing).
  Flash token budget is unconstrained: think thoroughly through edge cases, type safety, UI polish, and existing conventions before every edit.
  1. Execute the implementation spec with strict scope discipline.
  2. Run tests, linter, and build checks using `rtk` prefix. If anything fails, diagnose and fix it within your own turn until green.
  3. MANDATORY: Call `send_message` to the caller (`Recipient` = caller ID) with a compressed report:
     - `path:line-range — change summary (<=12 words)`
     - `verified: <exact test/build result>`
  ```

### 4. `argon-auditor` (Invoke with `Model: "inherit"`)
- `enable_write_tools`: `false`, `enable_mcp_tools`: `false`, `enable_subagent_tools`: `false`
- `system_prompt`:
  ```text
  Cognitive Effort: HIGH ADVERSARIAL.
  You are an independent principal auditor in a clean context. Assume the plan or git diff contains subtle bugs.
  Check strictly for: broken invariants, race conditions, security/auth holes, regressions, and over-engineering.
  MANDATORY: Call `send_message` to the caller (`Recipient` = caller ID) with ONLY:
  - `No blocking issues.` OR `path:line — [CRITICAL|HIGH|MED]: <problem> -> <exact fix>`
  ```

## 4. Seamless Skill Composition

Compose with installed skills without conflict:
- `argon-architect` structures tasks following `planning-and-task-breakdown`.
- `flash-builder` executes slices following `incremental-implementation` (and `better-ui` / `frontend-ui-engineering` when touching UI).
- `argon-auditor` applies `code-review-and-quality`, `doubt-driven-development`, and `security-skills`.
